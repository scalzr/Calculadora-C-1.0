﻿// See https://aka.ms/new-console-template for more information

using System;

namespace Calculadora
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Calculadora Simples\n");
                Console.WriteLine("Escolha a operação:");
                Console.WriteLine("1 - Adição");
                Console.WriteLine("2 - Subtração");
                Console.WriteLine("3 - Multiplicação");
                Console.WriteLine("4 - Divisão");
                Console.WriteLine("5 - Sair");
                Console.Write("Opção: ");

                string opcao = Console.ReadLine();

                if (opcao == "5")
                    break;

                Console.Write("\nDigite o primeiro número: ");
                double num1 = Convert.ToDouble(Console.ReadLine());

                Console.Write("Digite o segundo número: ");
                double num2 = Convert.ToDouble(Console.ReadLine());

                double resultado = 0;

                switch (opcao)
                {
                    case "1":
                        resultado = Adicao(num1, num2);
                        Console.WriteLine($"\nResultado: {num1} + {num2} = {resultado}");
                        break;
                    case "2":
                        resultado = Subtracao(num1, num2);
                        Console.WriteLine($"\nResultado: {num1} - {num2} = {resultado}");
                        break;
                    case "3":
                        resultado = Multiplicacao(num1, num2);
                        Console.WriteLine($"\nResultado: {num1} * {num2} = {resultado}");
                        break;
                    case "4":
                        if (num2 != 0)
                        {
                            resultado = Divisao(num1, num2);
                            Console.WriteLine($"\nResultado: {num1} / {num2} = {resultado}");
                        }
                        else
                        {
                            Console.WriteLine("\nErro: Divisão por zero!");
                        }
                        break;
                    default:
                        Console.WriteLine("\nOpção inválida!");
                        break;
                }

                Console.WriteLine("\nPressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }

        static double Adicao(double a, double b) => a + b;
        static double Subtracao(double a, double b) => a - b;
        static double Multiplicacao(double a, double b) => a * b;
        static double Divisao(double a, double b) => a / b;
    }
}
